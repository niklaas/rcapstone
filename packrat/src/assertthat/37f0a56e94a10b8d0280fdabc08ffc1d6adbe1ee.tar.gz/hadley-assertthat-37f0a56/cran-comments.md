## Test environments
* local OS X install, R 3.3.2
* ubuntu 12.04 (on travis-ci), R 3.3.2
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* checking CRAN incoming feasibility ... NOTE
  New maintainer:
    Hadley Wickham <hadley@rstudio.com>
  Old maintainer(s):
    'Hadley Wickham' <h.wickham@gmail.com>
    
  I have updated my email address.

## Reverse dependencies

I ran R CMD check on all 79 reverse dependencies. I didn't see any problems related to assertthat.